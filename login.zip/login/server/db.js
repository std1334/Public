const mongoose = require('mongoose');
const uri = "mongodb+srv://s1334073:Ss69928045@cluster0.guspwxu.mongodb.net/?retryWrites=true&w=majority";

async function connectdb() {
    try {
        await mongoose.connect(uri);
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error(error);
    }
}

module.exports = connectdb;
