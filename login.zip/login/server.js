const express = require('express');
const mongoose = require('mongoose');
const connectdb = require('./server/db');
const session = require('cookie-session');
const bodyParser = require('body-parser');
const app = express();
const users = require("./Models/schema")

app.set('view engine','ejs');

const KEY = 'LOGIN';

connectdb();

app.use(session({
  name: 'loginSession',
  keys: [KEY]
}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req,res) => {
	console.log(req.session);
	if (!req.session.authenticated) {    // user not logged in!
		res.redirect('/login');
	} else {
		res.status(200).render('secrets',{name:req.session.username});
	}
});

app.get('/login', (req,res) => {
	res.status(200).render('login',{});
});

app.post('/login', async (req,res) => {

    try {
        const check = await users.findOne({ name: req.body.name })
        
        if (check.password === req.body.password) {
            req.session.authenticated = true;
	    req.session.username = req.body.name;
	    
        }
        
        else {
            return res.redirect('/')

        }
    }     
    catch (e) {
        return res.redirect('/')    
    }
    
res.redirect('/');
});

app.get('/logout', (req,res) => {
	req.session = null;   // clear cookie-session
	res.redirect('/');
});

app.listen(process.env.PORT || 8000);
